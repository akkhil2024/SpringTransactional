package com.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    public SwaggerConfig(){
        System.out.println("Inside swagger config...");
    }
}
