package com.javatechie.ChapterFirst;

public class DemoService {


    public DemoService(){
        System.out.println("Inside Demo service bean................");
    }
}
