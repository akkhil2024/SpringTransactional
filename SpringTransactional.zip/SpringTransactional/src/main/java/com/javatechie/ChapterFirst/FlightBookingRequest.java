package com.javatechie.ChapterFirst;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightBookingRequest {

    private PassangerInfo passengerInfo;

    private PaymentInfo paymentInfo;
}
