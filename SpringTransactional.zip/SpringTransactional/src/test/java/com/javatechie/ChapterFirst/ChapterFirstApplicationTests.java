package com.javatechie.ChapterFirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChapterFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
